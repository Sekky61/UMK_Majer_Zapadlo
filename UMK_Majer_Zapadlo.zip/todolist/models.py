from django.db import models
from django.contrib.auth.models import User
from datetime import datetime
# Create your models here.
class Task(models.Model):
	headline = models.CharField(max_length= 255)
	text = models.TextField()
	author = models.ForeignKey(to=User, null=True, on_delete= models.SET_NULL, editable = False)
	shared_with_users = models.ManyToManyField(to=User, related_name="+")
	date_of_creation = models.DateField(default=datetime.now, editable = False)
	deadline = models.DateField(default=datetime.now, blank=True)
	
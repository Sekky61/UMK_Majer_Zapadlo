from django.db import models
from django.contrib.auth.models import User
import datetime

# Create your models here.
class Task(models.Model):
	headline = models.CharField(max_length= 255)
	text = models.TextField()
	done = models.BooleanField(default=False)
	author = models.ForeignKey(to=User, null=True, on_delete= models.SET_NULL)
	shared_with_users = models.ManyToManyField(to=User, related_name="+")
	date_of_creation = models.DateField(default=datetime.date.today, editable = False)
	deadline = models.DateField(default=datetime.date.today, blank=True)
	
	
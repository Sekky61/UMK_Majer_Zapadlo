from django.shortcuts import render
from .models import Task
from django.utils import timezone
import django.contrib.auth
from .forms import PostForm
from django.shortcuts import redirect


prvni = Task.objects.first()
# Create your views here.
def home(request):
	tasks = Task.objects.all() #.filter(date_of_creation=timezone.now()).order_by('date_of_creation')
	return render(request, "home.html", context={"jedna":prvni, 'Tasks': tasks, 'content': PostForm} ) 
	
#def	login_page(request):
#	return render(request, "login_page.html")

def post_new(request):
    if request.method == "POST":
        form = PostForm(request.POST)
        if form.is_valid():
            post = form.save(commit=False)
            post.author = request.user
            post.date_of_creation = timezone.now()
            post.save()
            return redirect('', pk=post.pk)
    else:
        form = PostForm()
    return render(request, 'post_edit.html', {'form': form})
from django.shortcuts import render
from .models import Task
import django.contrib.auth

prvni = Task.objects.first()
# Create your views here.
def home(request):
	return render(request, "home.html", context={"jedna":prvni} ) 
	
def	login_page(request):
	return render(request, "login_page.html")